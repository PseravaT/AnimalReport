package com.AV3.AnimalReport.model.formularios;

import com.AV3.AnimalReport.enums.EnumNivelUrgencia;
import com.AV3.AnimalReport.enums.EnumTipoAnimal;
import com.AV3.AnimalReport.model.usuarios.Organizacao;
import com.AV3.AnimalReport.model.usuarios.Usuario;
import jakarta.persistence.*;

@Entity
@DiscriminatorValue("DENUNCIA")
public class Denuncia extends Formulario {

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private EnumNivelUrgencia urgencia;

    @Column(nullable = true)
    @ManyToOne
    private Organizacao organizacaoResponsavel;

    //Construtores
    public Denuncia () {}

    public Denuncia(Long id, byte[] foto, EnumTipoAnimal tipoAnimal, String descricao, Usuario usuarioCriador, String cep, String rua, String bairro, String municipio, String estado, String complemento, EnumNivelUrgencia urgencia, Organizacao organizacaoResponsavel) {
        super(id, foto, tipoAnimal, descricao, usuarioCriador, cep, rua, bairro, municipio, estado, complemento);
        this.urgencia = urgencia;
        this.organizacaoResponsavel = organizacaoResponsavel;
    }

    //Getters e Setters

    public EnumNivelUrgencia getUrgencia() {
        return urgencia;
    }

    public void setUrgencia(EnumNivelUrgencia urgencia) {
        this.urgencia = urgencia;
    }

    public Organizacao getOrganizacaoResponsavel() {
        return organizacaoResponsavel;
    }

    public void setOrganizacaoResponsavel(Organizacao organizacaoResponsavel) {
        this.organizacaoResponsavel = organizacaoResponsavel;
    }
}
