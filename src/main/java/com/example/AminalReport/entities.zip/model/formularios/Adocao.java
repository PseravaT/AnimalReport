package com.AV3.AnimalReport.model.formularios;

import com.AV3.AnimalReport.enums.EnumTipoAnimal;
import com.AV3.AnimalReport.model.usuarios.Usuario;
import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("ADOCAO")
public class Adocao extends Formulario{

    @Column
    private String nomeAnimal;

    @Column
    private Integer idadeEstimada;

    //Construtores
    public Adocao () {}

    public Adocao(Long id, byte[] foto, EnumTipoAnimal tipoAnimal, String descricao, Usuario usuarioCriador, String cep, String rua, String bairro, String municipio, String estado, String complemento, String nomeAnimal, Integer idadeEstimada) {
        super(id, foto, tipoAnimal, descricao, usuarioCriador, cep, rua, bairro, municipio, estado, complemento);
        this.nomeAnimal = nomeAnimal;
        this.idadeEstimada = idadeEstimada;
    }

    //Getters e Setters

    public String getNomeAnimal() {
        return nomeAnimal;
    }

    public void setNomeAnimal(String nomeAnimal) {
        this.nomeAnimal = nomeAnimal;
    }

    public Integer getIdadeEstimada() {
        return idadeEstimada;
    }

    public void setIdadeEstimada(Integer idadeEstimada) {
        this.idadeEstimada = idadeEstimada;
    }
}
