package com.AV3.AnimalReport.enums;

public enum EnumStatusUsuario {
    ATIVO,
    DESATIVADO,
    SUSUPENSO
}
