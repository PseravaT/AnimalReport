package com.AV3.AnimalReport.enums;

public enum EnumTipoOrg {
    ONG,
    SECRETARIA_MUNICIPAL,
    POLICIA_AMBIENTAL
}
