package com.AV3.AnimalReport.enums;

public enum EnumNivelUrgencia {
    NAO_URGENTE,
    POUCO_URGENTE,
    URGENTE
}
