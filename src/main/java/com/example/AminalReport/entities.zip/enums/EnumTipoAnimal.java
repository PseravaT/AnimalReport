package com.AV3.AnimalReport.enums;

public enum EnumTipoAnimal {
    CACHORRO,
    GATO,
    PASSARO,
    CAVALO,
    BOI,
    VACA,
    PORCO,
    CABRA,
    OVELHA,
    GALINHA,
    PATO,
    PEIXE,
    COELHO,
    TARTARUGA,
    ANIMAL_SILVESTRE,
    OUTRO
}
